# Toll Management Application

We want to build an application which helps a toll company in managing different tolls across India.
There is a toll company having tolls across the country, with each toll having multiple toll booths.
Tolls have 3 kinds of toll pass
- Single Pass (one time use)
- Return pass (valid for current trip and one return trip within 24 hours)
- 7 day pass (unlimited passages in either direction for 7 days for that toll)
There are two kinds of vehicles - Two Wheeler and a 4 wheeler with different charges for above mentioned kinds of toll passes.

## Assume that:
Tolls and Toll Booths are already registered in the system. APIs to register them are not needed.
Vehicle can be identified by its registration number.
Payment is handled offline. You only need to keep track of the sales.

## Demonstrate:
Given a vehicle registration number and toll,
If the vehicle has a valid pass, show the existing toll pass and let the vehicle go through.
If there is no active pass, display charges for 3 different passes and allow the vehicle to choose one.
Build leaderboard of toll booth by number of vehicles processed and toll charges collected.

## Evaluation Criteria:
Code walkthrough to showcase structure and modelling.
A demonstration of the functional requirements stated above.
For the demonstration, you can choose any of - CLI, API, Unit tests or a runner class.

## Additional Notes:
- You may use any programming language.
- Database is optional. We don’t recommend setting up a db, it takes a lot of time. In memory stores or flat files are acceptable for storing data.
- You may access documentation and any other resources as needed.gg

## Build

```
npm install
```

## Run
```
npm start
```

## Queries:

#### Get data universe:
```
curl -X GET localhost:8000
```


#### Use a pass:
```
curl -X POST -H 'content-type: application/json' -d '{"vehicle_registration": "KA01-AB-4321", "booth_id": "1:1"}' localhost:8000/toll
```
