const express = require('express');
const app = express()
const port = 8000
const util = require('util')
var services = require('./lib/services');
const bodyParser = require('body-parser')
app.use(express.json())

app.get("/", function(req, res) {
    res.json({
        "status": services.status()
    });
});

app.post("/toll", function(req, res) {
    console.debug(`POST /toll: ${util.inspect(req.body, {})}`);
    const vehicle_registration = req.body.vehicle_registration;
    const booth_id = req.body.booth_id;

    // TODO - coalesce errors
    if(!vehicle_registration) {
        return res.status(404).json({
            "status": "vehicle_registration required"
        });
    }
    if(!booth_id) {
        return res.status(404).json({
            "status": "booth_id required"
        });
    }

    services.process_transaction(vehicle_registration, booth_id, function(err) {
        if(err) {
            return res.status(500).json({
                "status": err
            });
            // TODO disambiguate between client and server errors by deeper switch/casing here
        } else {
            return res.status(200).json({
                "status": "ok - processed"
            });
        }
    });
});

app.listen(port, function() {
    console.log(`Listening on port ${port}`);
});
